
import com.amazonaws.services.lambda.runtime.*;

public class HelloLamda implements RequestHandler<String, String> {
    @Override
    public String handleRequest(String input, Context context) {
        String output = "Hello, " + input + "!!!!";
        return output;
    }
}
